package com.kwon.ucf.notice_board;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.kwon.ucf.R;
import com.kwon.ucf.application.ApplicationController;
import com.kwon.ucf.network.NetworkService;
import com.kwon.ucf.network.RetrofitClass;
import com.kwon.ucf.today_menu.MenuAdapter;

import junit.framework.Test;

import org.json.JSONArray;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;


//게시판
@SuppressLint("ValidFragment")
public class Fragment2 extends Fragment  {


    private NetworkService mRetro = new RetrofitClass().getRetroService();
    NetworkService service; /////////////////
    ArrayList<CommentData> cData;///////////////

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment2, container, false);


//
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) { // 문제점 : 리사이클러뷰가 에딧텍스트를 눌러야 뜸. 질문 : 액티비티 생성될때 말고 프래그먼트 생성될때 넣어야되나여? 밥먹고오겠슴다
        super.onActivityCreated(savedInstanceState);
        View v = this.getView();

        LinearLayoutManager cLayoutManager;
        BoardAdapter boardAdapter;


        RecyclerView recyclerView2;
        recyclerView2 = (RecyclerView) v.findViewById(R.id.recyclerView2);


        recyclerView2.setHasFixedSize(true);

        cLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView2.setLayoutManager(cLayoutManager);

        boardAdapter = new BoardAdapter(cData);
        recyclerView2.setAdapter(boardAdapter);


        //리사이클러뷰 넣어야함


        //
        final EditText txt_commemt;
        final Button send_comment;

        txt_commemt = (EditText) v.findViewById(R.id.txt_comment);
        send_comment = (Button) v.findViewById(R.id.send_comment);

        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(100);
        txt_commemt.setFilters(FilterArray);


        send_comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String comment = txt_commemt.getText().toString(); //  보낼 string 정의

                mRetro.sendComment(comment).enqueue(new Callback<JsonArray>() {
                    @Override
                    public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                        if (response.code() == 200) {
                            JsonArray json = response.body(); //

                        }
                    }

                    @Override
                    public void onFailure(Call<JsonArray> call, Throwable t) {

                    }

                });


            }

        });

    }

    public interface ServerPost {
        @FormUrlEncoded
        @POST("/board")
        Call<JSONArray> sendComment(@Field("txt_comment") String getComment);
    }

    // post로 comment 보내기 기능


    ////////////////

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initCommentDataset();        // 데이터 띄우기
    }

    private void initCommentDataset() { //initDataset 참조한것. mData->cData로 바꿔서 했음. MenuData 참조하여 CommentData 클래스 만듦
        cData = new ArrayList<>(); //cData 생성

        service = ApplicationController.getInstance().getNetworkService();
        service.getComment().enqueue(new Callback<JsonArray>() {
            @Override
            public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                if (response.code() == 200) {
                    JsonArray arr = response.body();
                    for (int i = 0; i < arr.size(); i++) {
                        JsonObject item = arr.get(i).getAsJsonObject();
                        cData.add(new CommentData(item.get("comment").getAsString(), item.get("date").getAsString())); // cData에 comment, date 넣음

                    }
                }
            }

            @Override
            public void onFailure(Call<JsonArray> call, Throwable t) {

            }
        });
        //cData.add(new CommentData("맛있네요","2018/06/02"));


    }




}




