package com.kwon.ucf.Realm;

import android.media.Image;
import android.util.Log;
import android.app.Activity;
import android.util.Log;

import java.util.ArrayList;

import io.realm.Realm;
import io.realm.RealmResults;


/**
 * Created by song on 2018-06-06.
 */

public class MyReviewHelper {
    private String returnImageUrl ="";

    public void createImage(Realm realm, final String imageUrl) {
        Log.e("테스트", "DB생성");
        // All writes must be wrapped in a transaction to facilitate safe multi threading


        realm.executeTransaction(new Realm.Transaction() { //저장하기
            @Override
            public void execute(Realm realm) {
                MyReview myReview = new MyReview(); //객체 생성
                myReview.reviewRating = 0;//별점입력값 받기
                myReview.comment = "" ;// 코멘트입력값 받기 이런식으로 넣엉
                long date = 0; // 작성날짜받기
                String imageUrl = ""; // 이미지url받기
                realm.insert(myReview); //myReview를 내장 db에 저장

            }
        });



        MyReview myReview = realm.where(MyReview.class).equalTo("FoodName","음식이름").findFirst(); //여기서 이미 해당 음식이름으로 객체를 가져왔기 때문에
        //그리고 기준 즉 기본키같은데 음식이름일꺼니까 FoodName으로 한거고 ㅇㅋ? 아아아아아 넵
        String comment = myReview.comment; //이런식으로 자 이제 궁금한거  그럼 대우형이 레이아웃 짜놓고 값 불러올때는 또 궁금한거  감사함당 이따 또 물어볼게여 있으면ㅇㅇ
        String url = myReview.imageUrl; //그냥 이미지 유알엘 이런식으로 불르면 되지 ㅇㅇㅋ? 아아아 이렇게 하나씩 불러올수있는거네여 ㅇ

        // 내리뷰 저장했을때 보여주는 상황. 메뉴 하나 누르면 다이얼로그 띄우고 푸드네임값으로 식별해서. 사진, 평점 등 다 이렇게 받아와서 띄워줌.
    }

    public boolean isCheckClassFile(Realm realm) {
        final Boolean[] result = {false}; //
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                MyReview myReview = realm.where(MyReview.class).findFirst(); // DB에서 첫번째 값 가져오기

                if (myReview == null) {
                    result[0] = false;
                } else {
                    result[0] = true;
                }
            } // 내 리뷰가 존재하는지 확인하는 함수. 내 리뷰가 있으면 db에 있는 정보띄워주면 되고, 없으면 "아직 리뷰가 없어요" 띄우기
        });
        return result[0];
    }


    public void clearImageHelper(Realm realm){
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.delete(MyReview.class);
            }
        });
    }  //DB 삭제
}