package com.kwon.ucf.notice_board;

/**
 * Created by song on 2018-06-05.
 */

public class CommentData {
    public String comment;
    public String date;


    public CommentData(String comment, String date) {
        this.comment = comment;
        this.date = date;

    }
}