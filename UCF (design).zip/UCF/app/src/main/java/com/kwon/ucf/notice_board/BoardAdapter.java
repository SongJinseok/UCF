package com.kwon.ucf.notice_board;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.kwon.ucf.R;

import java.util.ArrayList;

public class BoardAdapter extends RecyclerView.Adapter<MyViewHolder2>{
    ArrayList<CommentData> commentData;
    public BoardAdapter(ArrayList<CommentData> commentData) {
        this.commentData = commentData;
    }

    public ArrayList<CommentData> getCommentData() {
        return commentData;
    }

    @NonNull
    @Override
    public MyViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment_list_item, parent, false);
        return new MyViewHolder2(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder2 holder, int position) {
        holder.tv_comment.setText(commentData.get(position).comment);
        holder.tv_date.setText(commentData.get(position).date);
    }

    @Override
    public int getItemCount() {
        return commentData == null ? 0 : commentData.size();
    }
}
