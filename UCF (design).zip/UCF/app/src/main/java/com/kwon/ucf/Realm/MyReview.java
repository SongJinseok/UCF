package com.kwon.ucf.Realm;

import android.media.Image;

import io.realm.RealmModel;
import io.realm.RealmObject;
import io.realm.annotations.Ignore;
import io.realm.annotations.RealmClass;

/**
 * Created by song on 2018-06-06.
 */

@RealmClass
public class MyReview implements RealmModel { //

    String FoodName = "";
    int reviewRating = 0; // 그리고 별점이 왜 스트링이야
    String comment = ""; // 평가
    long date = 0; // 작성날짜
    String imageUrl = ""; // 이미지

}

