package com.kwon.ucf.notice_board;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.kwon.ucf.R;

class MyViewHolder2 extends RecyclerView.ViewHolder {
    TextView tv_comment;
    TextView tv_date; //


    public MyViewHolder2(View itemView) {
        super(itemView);
        tv_comment = (TextView)itemView.findViewById(R.id.tv_comment);
        tv_date = (TextView)itemView.findViewById(R.id.tv_date);

    }
}
